﻿using System.Windows.Controls;

namespace DotNetSimaticDatabaseProtokollerConfigurationTool.Windows
{
    public partial class SubwindowInformation : UserControl
    {
        public SubwindowInformation()
        {
            InitializeComponent();
        }
                    
    }
}
