﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DotNetSimaticDatabaseProtokollerLibrary
{
    public static class StaticServiceConfig
    {
        public const string Company = "JFK-Solutions";  
        public const string MyServiceName = "JFK-Protokoller";        
    }
}
