﻿namespace DotNetSimaticDatabaseProtokollerLibrary.Common
{
    public enum LogErrorLevel
    {
        None = 0,
        Error = 1,
        Warning = 2,
        Information = 3  
    }
}
