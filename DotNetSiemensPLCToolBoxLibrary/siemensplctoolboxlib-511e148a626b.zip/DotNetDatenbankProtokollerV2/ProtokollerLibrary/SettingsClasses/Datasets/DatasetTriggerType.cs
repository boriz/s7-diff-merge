﻿namespace DotNetSimaticDatabaseProtokollerLibrary.SettingsClasses.Datasets
{
    public enum DatasetTriggerType
    {
        Time_Trigger = 0,
        Tags_Handshake_Trigger = 1,
        Triggered_By_Incoming_Data_On_A_TCPIP_Connection = 2,
        Quartz_Trigger = 3,
        Time_Trigger_With_Value_Comparison = 4
    }
}
