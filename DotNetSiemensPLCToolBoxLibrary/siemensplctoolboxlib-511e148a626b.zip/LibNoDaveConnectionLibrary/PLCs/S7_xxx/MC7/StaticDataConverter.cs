﻿namespace DotNetSiemensPLCToolBoxLibrary.PLCs.S7_xxx.MC7
{
    class StaticDataConverter
    {
    }
}
