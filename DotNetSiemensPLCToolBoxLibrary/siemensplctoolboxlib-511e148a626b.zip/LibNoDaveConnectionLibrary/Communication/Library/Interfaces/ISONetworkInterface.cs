﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetSiemensPLCToolBoxLibrary.Communication.Library.Interfaces
{

    /*
    public abstract class ISONetworkInterface:NetworkInterface
    {

    }
     * */
}
