﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Text;

namespace DotNetSiemensPLCToolBoxLibrary.Communication.Library
{
    /*
    public class SerialInterface:Interface
    {
        private SerialPort _serialPort;

        public SerialInterface(string portName, int baudRate, Parity parity, int dataBits, StopBits stopBits)
        {
            _serialPort = new SerialPort(portName, baudRate, parity, dataBits, stopBits);
            
            _serialPort.Open();
        }
    }
    */
}
