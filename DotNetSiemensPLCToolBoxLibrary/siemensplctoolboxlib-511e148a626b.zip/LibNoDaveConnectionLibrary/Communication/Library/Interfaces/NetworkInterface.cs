﻿using System;
using System.Threading;

namespace DotNetSiemensPLCToolBoxLibrary.Communication.Library.Interfaces
{
    /*
    public abstract class NetworkInterface : Interface
    {
        private TCPConnection _tcpConnection;

        private byte[] _recievedData;
        
        protected NetworkInterface()
        {
        }

        protected void sendPacket(byte[] data)
        {
            _tcpConnection.SendData(data);
        }

        protected byte[] readPacket()
        {
            _recievedData = null;
            DateTime start = DateTime.Now;
            while (_recievedData == null && DateTime.Now > (start + TimeOut))
            { Thread.Sleep(1); }

            return _recievedData;
        }

    }*/
}
