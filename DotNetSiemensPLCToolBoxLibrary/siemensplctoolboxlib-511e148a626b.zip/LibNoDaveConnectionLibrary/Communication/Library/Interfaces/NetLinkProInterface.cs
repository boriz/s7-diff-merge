﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetSiemensPLCToolBoxLibrary.Communication.Library
{
    /*
    public class NetLinkProInterface:NetworkInterface
    {
    }
    */
}
