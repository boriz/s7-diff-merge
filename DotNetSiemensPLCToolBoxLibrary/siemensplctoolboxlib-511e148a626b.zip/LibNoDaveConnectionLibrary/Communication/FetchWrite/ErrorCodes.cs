﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DotNetSiemensPLCToolBoxLibrary.Communication.FetchWrite
{
    public enum ErrorCodes
    {
        Invalid_header,
        Bad_reply,
    }
}
