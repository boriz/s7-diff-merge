﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes
{
    public class PLCMemoryInfo
    {
    }
}
