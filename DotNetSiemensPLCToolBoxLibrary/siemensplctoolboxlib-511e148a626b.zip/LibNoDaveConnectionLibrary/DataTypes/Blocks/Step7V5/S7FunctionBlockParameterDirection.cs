﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Blocks.Step7V5
{
    public enum S7FunctionBlockParameterDirection
    {
        IN = 0,
        IN_OUT = 1,
        OUT = 2,
    }
}
