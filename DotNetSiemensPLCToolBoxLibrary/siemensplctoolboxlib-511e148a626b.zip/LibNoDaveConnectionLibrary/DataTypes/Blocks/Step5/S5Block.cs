﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Blocks.Step5
{
    public class S5Block : Block
    {
        public byte[] blockByteArray;
        public bool deleted;
    }
}
