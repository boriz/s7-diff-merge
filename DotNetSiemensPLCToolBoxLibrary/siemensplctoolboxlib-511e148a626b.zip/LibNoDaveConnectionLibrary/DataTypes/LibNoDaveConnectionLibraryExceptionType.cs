﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes
{
    public enum WPFToolboxForSiemensPLCsExceptionType
    {
        ErrorReadingSZL=100,
    }
}
