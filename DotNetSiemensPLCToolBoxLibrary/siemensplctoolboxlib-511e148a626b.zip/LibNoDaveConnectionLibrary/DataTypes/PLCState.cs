﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes
{
    public enum PLCState
    {
        Running = 0,
        Starting = 1,
        Stopped = 2,
    }
}
