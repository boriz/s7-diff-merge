﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes
{
    public enum ConnectionTargetPLCType
    {
        S7 = 0,
        S5 = 1,
        S7_200 = 2,
        S7_1200= 3,
    }
}
