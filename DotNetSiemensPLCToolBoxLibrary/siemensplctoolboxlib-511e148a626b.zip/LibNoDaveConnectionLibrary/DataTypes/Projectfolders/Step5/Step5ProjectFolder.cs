﻿using System;

namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders.Step5
{
    public class Step5ProjectFolder : ProjectFolder
    {
        
    }
}
