﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders.Step7V5
{
    /// <summary>
    /// Base Abstract Class for every Project Folder.
    /// </summary>
    public class Step7ProjectFolder:ProjectFolder
    {
       
    }
}
