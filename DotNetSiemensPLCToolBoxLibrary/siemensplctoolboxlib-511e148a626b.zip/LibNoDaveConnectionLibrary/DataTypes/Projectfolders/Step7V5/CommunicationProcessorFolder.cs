﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders.Step7V5
{
    public class CommunicationProcessorFolder : Step7ProjectFolder
    {

    }
}
