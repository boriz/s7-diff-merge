﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders.Step7V5
{
    public class HardwareConfigFolder : Step7ProjectFolder
    {

    }
}
