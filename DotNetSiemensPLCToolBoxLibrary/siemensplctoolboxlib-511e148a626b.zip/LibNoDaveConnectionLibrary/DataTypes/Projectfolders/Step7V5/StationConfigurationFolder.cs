﻿namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders.Step7V5
{
    public class StationConfigurationFolder : Step7ProjectFolder
    {
        internal int UnitID;
        public PLCType StationType { get; set; } 
    }
}
