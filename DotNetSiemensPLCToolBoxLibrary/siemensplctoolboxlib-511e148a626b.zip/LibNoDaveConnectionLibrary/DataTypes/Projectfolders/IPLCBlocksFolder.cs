﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders
{
    interface IPLCBlocksFolder : IBlocksFolder
    {
    }
}
