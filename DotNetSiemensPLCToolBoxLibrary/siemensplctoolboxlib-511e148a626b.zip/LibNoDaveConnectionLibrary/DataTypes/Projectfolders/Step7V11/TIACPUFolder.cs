﻿using DotNetSiemensPLCToolBoxLibrary.Projectfiles;

namespace DotNetSiemensPLCToolBoxLibrary.DataTypes.Projectfolders.Step7V5
{
    public class TIACPUFolder : TIAProjectFolder
    {
        public TIACPUFolder(Step7ProjectV11 Project)
            : base(Project)
        {
        }
    }
}
